# P. Islamic Academy

Toleo la mwanzo la tovuti ya P. Islamic Academy.

## Mafaili
- `index.html` — ukurasa mkuu.
- `style.css` — muonekano wa tovuti.
- `app.js` — menyu na Pi Sign-In ya mwanzo.
- `logo.svg` — nembo ya chuo.

## Kuweka GitHub Pages
1. Pakia mafaili yote kwenye repository `Pi-islamic-academiy`.
2. Hakikisha `index.html` ipo kwenye mzizi wa repository (si ndani ya folder nyingine).
3. Fungua **Settings → Pages**.
4. Chagua **Deploy from a branch**, branch `main`, folder `/ (root)`, kisha Save.

## Pi Network
Tovuti hii imeandaliwa kwa Pi SDK v2.0 katika Sandbox mode kwa majaribio. Hakuna malipo ya Pi yaliyowezeshwa. Kabla ya uzinduzi, hakikisha app imeunganishwa na URL sahihi kwenye Developer Portal. Kwa uzalishaji, tumia `sandbox: false` baada ya kuthibitisha mazingira na mipangilio ya app.

**Usiweke Server API Key au siri nyingine ndani ya mafaili ya frontend.** Uthibitishaji kamili wa mtumiaji na malipo huhitaji backend salama.
