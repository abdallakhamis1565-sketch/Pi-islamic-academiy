const year = document.getElementById("year");
year.textContent = new Date().getFullYear();

const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");
menuBtn.addEventListener("click", () => nav.classList.toggle("open"));

const loginBtn = document.getElementById("piLogin");
const statusText = document.getElementById("piStatus");

let piReady = false;
(async function initPi() {
  try {
    if (window.Pi) {
      // Toleo la sasa la mradi ni la majaribio (Sandbox/Testnet).
      await window.Pi.init({ version: "2.0", sandbox: true });
      piReady = true;
      statusText.textContent = "Pi SDK imeandaliwa. Bonyeza “Ingia kwa Pi” ukiwa ndani ya Pi Browser.";
    } else {
      statusText.textContent = "Pi Browser inahitajika kwa kuingia kwa Pi. Unaweza kuendelea kusoma tovuti.";
    }
  } catch (error) {
    statusText.textContent = "Pi SDK haikuweza kuanzishwa kwenye kivinjari hiki. Jaribu ndani ya Pi Browser.";
  }
})();

loginBtn.addEventListener("click", async () => {
  if (!piReady || !window.Pi) {
    statusText.textContent = "Fungua tovuti hii ndani ya Pi Browser ili kutumia Pi Sign-In.";
    return;
  }
  loginBtn.disabled = true;
  loginBtn.textContent = "Inaingia...";
  try {
    const auth = await window.Pi.authenticate(["username"], () => {});
    const username = auth && auth.user ? auth.user.username : "Mwanafunzi";
    statusText.textContent = `Karibu, ${username}! Umeingia kwa Pi.`;
    loginBtn.textContent = "Umeingia";
  } catch (error) {
    statusText.textContent = "Kuingia hakukukamilika. Jaribu tena ndani ya Pi Browser.";
    loginBtn.disabled = false;
    loginBtn.textContent = "Ingia kwa Pi";
  }
});